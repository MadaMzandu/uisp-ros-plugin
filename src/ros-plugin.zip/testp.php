<?php
include_once "lib/api_ip.php";
include_once "lib/timer.php";
$d = [
    'pool' => '192.168.88.0/24',
    'pool6' => 'fda7:5f1d:34e8::/48',
];

$i = new API_IP();
$a = $i->assign((object)$d);
var_dump($a);

//$file = file_get_contents('test2.json');
/*$data = json_decode($file);
$a = new API_Router($data);
$a->route();
echo json_encode($a->status()) . "\n";*/
/*
$requests = json_decode($file);
$count = 0 ;
foreach ($requests as $data){
    echo "Run: " . ++$count . "\n";
    $a = new API_Router($data);
    $a->route();
    echo json_encode($a->status()) ."\n";
}*/


