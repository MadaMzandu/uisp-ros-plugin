<?php
include_once 'lib/api_router.php';

$file = file_get_contents('one.json');
$data = json_decode($file);
$a = new API_Router($data);
$a->route();
echo $a->status() . "\n";