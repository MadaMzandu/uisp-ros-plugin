<?php
class Timer
{
    public $start ;
    public function __construct()
    {
        $this->start = microtime(true);
    }
    public function end($label=null,$reset=true)
    {
        $now = microtime(true);
        $dur = ($now - $this->start) * 1000;
        echo $label . " Duration: " . $dur . " milliseconds\n";
        if($reset)$this->start = $now ;
        return $dur ;
    }

}