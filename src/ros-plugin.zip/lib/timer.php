<?php
class Timer
{
    public $start ;
    public function __construct()
    {
        $this->start = microtime(true);
    }
    public function end()
    {
        $now = microtime(true);
        $dur = ($now - $this->start) * 1000;
        echo "Duration: " . $dur . " milliseconds\n";
        $this->start = $now ;
    }
}