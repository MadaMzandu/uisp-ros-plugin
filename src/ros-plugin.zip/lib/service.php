<?php


include_once 'service_account.php';

class Service extends Service_Account
{


}
