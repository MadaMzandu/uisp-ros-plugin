<?php
class ApiAutoUser
{
    private $request ;

    public function check()
    {
        $entity = $this->request->extraData->entity ?? $this->request ;
        $attributes = $entity['attributes'] ?? [] ;
    }

    private function db(){ return new ApiSqlite(); }

    private function conf(){ return $this->db()->readConfig(); }

    public function __construct($request = [])
    {
        $this->request = $request ;
    }
}