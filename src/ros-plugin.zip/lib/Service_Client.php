<?php
include_once 'service_base.php'

class Service_Client extends Service_Base{

}
