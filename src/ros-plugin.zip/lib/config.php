<?php

// loads configuration from json file - obsolete

return json_decode(
        file_get_contents('json/config.json'));