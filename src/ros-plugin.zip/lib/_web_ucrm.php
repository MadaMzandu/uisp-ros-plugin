<?php


class WebUcrm
{

    public bool $assoc = false;
    public bool $ssl_disable = true ;
    private $ch;
    private string $key = '67830f0f-c732-4d32-b0e2-7458d4f97b52';
    private string $api = 'https://127.0.0.1/api/v1.0';


    public function request($url, $method = 'GET', $post = [])
    {
        $this->configure($url,$method,$post);
        return $this->exec();
    }

    public function get($path, $post = [])
    {
        $this->configure($path, 'GET', $post);
        return $this->exec();
    }

    public function patch($path, $post = [])
    {
        $this->configure($path, 'PATCH', $post);
        return $this->exec();
    }

    public function post($path, $post = [])
    {
        $this->configure($path, 'POST', $post);
        return $this->exec();
    }

    public function delete($path, $post = [])
    {
        $this->configure($path, 'DELETE', $post);
        return $this->exec();
    }

    private function configure($path, $method, $post)
    {
        $path = sprintf("%s/%s",
            trim($this->api,'/'),
            trim($path,'/'));
        $this->ch = curl_init();
        $opts = [
            CURLOPT_URL => $path,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => [
                sprintf("X-Auth-App-Key: %s",$this->key),
                'Content-Type: application/json' ],
        ];
        if($this->ssl_disable){
            $opts[CURLOPT_SSL_VERIFYPEER] = false;
            $opts[CURLOPT_SSL_VERIFYHOST] = false ;
        }
        if(!in_array($method,['GET'])){
            $opts[CURLOPT_POSTFIELDS] = json_encode($post);
        }
        else{
            $opts[CURLOPT_URL] = sprintf('%s?%s',$path,http_build_query($post));
        }
        curl_setopt_array($this->ch,$opts);
    }

    private function exec()
    {
        $response = curl_exec($this->ch);
        if (curl_errno($this->ch) !== 0) {
            echo sprintf('Curl error: %s', curl_error($this->ch)) . PHP_EOL;
        }
        if (curl_getinfo($this->ch, CURLINFO_HTTP_CODE) >= 400) {
            echo sprintf('API error: %s', $response) . PHP_EOL;
        }
        curl_close($this->ch);
        return $response !== false ? json_decode($response, $this->assoc) : null;
    }

}
