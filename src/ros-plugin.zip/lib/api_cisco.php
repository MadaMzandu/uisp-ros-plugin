<?php
use phpseclib3\Net\SSH2;

class Cisco extends Device
{
    protected $read;

    protected function init(): void
    {
        parent::init();
        //$this->data->device_id = 1 ;
    }

    public function test(){
        $read = preg_replace('/\r\n\h+/',',', // remove continuation spaces
            preg_replace('/,\h+/',',', // remove spaces after commas
            preg_replace('/\r\n\r\n/',"\r\nEND\r\n", // mark section endings
                $this->read())));
        $lines = preg_split('/\r\n/',$read);
        // $pattern = '/(\w+\ *)+\r\n(-+\ *)+\r\n/' ;
        $count =  0 ;
        $size = sizeof($lines);
        $fields = [];
        $array = [];
        while($count < $size){
            $line = $lines[$count];
            $matches = [];
            if(preg_match('/^-+/',$line,$matches)){
                $fields = preg_split('/\h+/',$lines[$count-1]);
                $count++ ;
                continue ;
            }
            if(!$fields){
                $count++;
                continue ;
            }
            if(preg_match('/^END/',$line)){
                $fields = [];
                $count++ ;
                continue;
            }
            $values = preg_split('/\h+/',$line);
            $s = sizeof($fields);
            if($s != sizeof($values)){
                $count++ ;
                continue;
            }
            $assoc = [];
            for($i=0;$i < $s;$i++){
                $assoc[$fields[$i]] = preg_match('/(\w+,)+/',$values[$i])
                    ? explode(',',$values[$i])
                    : $values[$i];
            }
            $array[] = $assoc ;
            $count++;
        }
        var_dump($array);
    }

    protected function read(){
        $ssh = $this->connect();
        return $ssh->exec('show vlan');
    }

    protected function findTables(){


        return null ;
    }

    protected function makeFields($map){
        $object = [];
        $keystrings = array_keys($map);
        foreach($keystrings as $string){
            $section = [];
            foreach ($map[$string] as $line){
                $keys = explode('FI3LD',$string);
                $size = sizeof($keys) ;
                $item = [];
                for($i=0;$i<$size;$i++){
                    $item[$keys[$i]] = explode('FI3LD',$line)[$i] ?? null;
                }
                $section[] = $item ;
            }
            $object[] = $section;
        }
        return $object ;
    }

    protected function connect()
    {
        if(!$this->getDevice()){
            // throw new Exception('failed to get device information');
        };
        $this->test_device();
        $ssh = new SSH2($this->device->ip);
        if(!$ssh->login($this->device->user,$this->device->password)){
            throw new Exception('authentication failed on the device');
        }
        return $ssh;
    }

    private function test_device(){
        $this->device = (object) [
            'ip' => '10.1.13.30',
            'user' => 'admin',
            'password' => 'kh0bidi08',
        ];
    }

}