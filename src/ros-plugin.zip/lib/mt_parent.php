<?php
class MtParent extends MT
{
    public function enable()
    {

    }

    private function disable()
    {

    }

    private function services()
    {
        $sql = "SELECT id FROM services WHERE status NOT IN (2,5,8)";
        $select = $this->dbCache()->selectCustom($sql);
        $ids = [];
        foreach($select as $item){$ids[] = $item['id']; }
        return $ids ;
    }

    private function plans()
    {
        $api = new AdminPlans();
        return $api->list();
    }

}