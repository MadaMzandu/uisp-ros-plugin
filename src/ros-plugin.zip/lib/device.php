<?php

// extend new device types from here

class Device extends Device_Account {
    
    
}