<?php
include_once 'device_fix.php';

// extend new device types from here

class Device extends Device_Fix
{


}