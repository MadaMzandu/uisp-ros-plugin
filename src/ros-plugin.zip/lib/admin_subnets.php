<?php
include_once 'timer.php';
class Subnets extends Admin
{
    private $pid;
    private $did ;

    public function assign($pid, $did): ?array
    {
        $this->pid = $pid ;
        $this->did = $did ;
        $unused = $this->find_unused($pid,$did);
        $check = $this->check_unused($unused);
        if ($check > 0)
            return $unused;
        else {
            $new = $this->find_new($check) ?? [];
            foreach (array_keys($unused) as $key) $new[$key] = $unused[$key];
            return $new;
        }
    }

    public function targets($pid,$did): ?string
    {
       $nets = $this->db()->selectPlanSubnets($pid,$did);
       $str = "";
       foreach($nets as $net){
           $addr = $net['address'] ?? null;
           if(!$addr) continue ;
           $type = $this->type($addr);
           if(!$type) continue ;
           $len = $type ==4 ? '/28' : '/54';
           $str .= $addr . $len . ',';
       }
       return trim($str,',');
    }

    public function clean_pool($pid,$did)
    {
        $tm = new Timer();
        $nets = $this->db()->selectPlanSubnets($pid,$did);
        $db = $this->db();
        foreach ($nets as $net){
            if($this->type($net['address']) != 4) continue;
            $range = $this->gmp_range($net['address']);
            $used = false ;
            for($s=$range['start'];$s <= $range['end'];$s++){
                $ip = $this->gmp2ip($s);
                if($this->is_odd($ip)) continue;
                if($db->ifIpAddressIsUsed($ip)){
                    $used = true ;
                    break;
                }
            }
            if(!$used) $db->delete($net['id'],'subnets');
        }
        $tm->end('CleanUp');
    }

    public function clean()
    {
        if(function_exists('fastcgi_finish_request'))
            fastcgi_finish_request();
        $orphans[] = $this->device_orphans();
        $orphans[] = $this->plan_orphans();
        $orphans[] = $this->pool_orphans();
        foreach ($orphans as $set) $this->delete($set);
    }

    public function used(): array
    {
        $nets = $this->db()->selectAllFromTable('subnets');
        if(!$nets) return [];
        $used = [];
        foreach ($nets as $net) {
            $addr = $net['address'] ?? null ;
            if(!$addr) continue ;
            $used[$addr] = 1 ;
        }
        return $used;
    }

    private function plan_orphans(): array
    {
        $d = [];
        $plans = (new Plans($d))->list();
        foreach ($plans as $plan) $pids[] = $plan['id'];
        $planSubnets = $this->get_subnets();
        foreach ($planSubnets as $net)
            if(!in_array($net['planId'],$pids)) $ids [] = $net['id'];
        return $ids ;
    }

    private function device_orphans(): array
    {
        $devices = $this->db()->selectAllFromTable('devices');
        foreach ($devices as $device) $dids[] = $device['id'] ?? null ;
        $planSubnets = $this->get_subnets();
        foreach ($planSubnets as $net)
            if(!in_array($net['did'],$dids)) $ids [] = $net['id'];
        return $ids ;
    }

    private function pool_orphans() : array
    {
        $devicePools = $this->get_pools();
        $planSubnets = $this->get_subnets();
        $notFound = [];
        foreach ($devicePools as $net) $ranges[] = $this->gmp_range($net);
        foreach($planSubnets as $subnet){
            $id = $subnet['id'] ;
            $ip = $subnet['address'] ?? null ;
            $addr = $this->ip2gmp($ip);
            $found = false ;
            foreach ($ranges as $range){
                if($addr >= $range['start'] && $addr <= $range['end']){
                    $found = true ;
                    break ;
                }
            }
            if(!$found) $notFound[] = $id ;
        }
        return $notFound ;
    }

    private function get_subnets(): array
    {
       return $this->db()
               ->selectAllFromTable('subnets') ?? [];
    }

    private function get_pools(): array
    {
        $devices = $this->db()->selectAllFromTable('devices');
        $str = "";
        foreach($devices as $device){
            foreach (['pool','pool6'] as $key) {
                $pool = $device[$key] ??  null ;
                if($pool) $str .= $pool . ",";
            }
        }
        return explode(',',trim($str,',')) ?? [];
    }

    private function delete(array $ids)
    {
        $db = $this->db();
        foreach($ids as $id){
            $db->delete($id,'subnets');
        }
    }

    private function check_unused($arr): int
    {
        if (empty($arr)) return 0;
        $pool6 = $arr['pool6'] ?? null;
        $pool = $arr['pool'] ?? null;
        if (!empty($pool) && !empty($pool6)) return 2;
        if (empty($pool)) return -1;
        return -2;
    }

    private function find_new($check): ?array
    {
        if ($check > 0 || $check < -2) return null;
        $device = $this->db()->selectDeviceById($this->did) ?? null;
        if (empty($device)) return null ;
        if ($check == -1) unset($device->pool6);
        if ($check == -2) unset($device->pool);
        $device->pLen = 28;
        $device->pfxLen = 54;
        $device->plan = true;
        $addr = (new API_IP())->assign($device);
        if ($addr && $this->save($addr)){
            $ret['pool'] = $addr['pool'] . '/28';
            $pool6 = $addr['pool6'] ?? null ;
            if($pool6) $ret['pool6'] = $pool6 . '/54';
            return $ret ;
        }
        return null;
    }

    private function save($addr): bool
    {
        $db = $this->db() ;
        $ret = true ;
        foreach($addr as $ip){
            if(!$ip) continue ;
            $ret &= $db->insert($this->data($ip),'subnets');
        }
        return $ret ;
    }

    private function data($ip): ?array
    {
        return [
            'planId' => $this->pid,
            'did' => $this->did,
            'address' => $ip,
        ];
    }

    private function find_unused(): ?array
    {
        $nets = $this->db()->selectPlanSubnets($this->pid,$this->did) ;
        if(!$nets) return [] ;
        $arr = [];
        foreach($nets as $net){
            $addr = $net['address'] ?? null ;
            if(!$this->check_prefix($addr))continue ;
            switch($this->type($addr)){
                case 4: $arr['pool'] = $addr . "/28"; break ;
                case 6: $arr['pool6'] = $addr . "/54"; break ;
                default: break ;
            }
        }
        return $arr ;
    }

    private function check_prefix($prefix): bool
    {
        if(!$this->type($prefix)) return false ; // validate here
        $range = $this->gmp_range($prefix);
        for ($addr = $range['start']; gmp_cmp($addr, $range['end']) < 0; $addr++) {
            $ip = $this->gmp2ip($addr);
            if ($this->is_odd($ip)) continue;
            $used = $this->db()->ifIpAddressIsUsed($ip);
            if (!$used) return true;
        }
        return false;
    }

    private function is_odd($address): bool
    {
        $type = $this->type($address);
        if ($type == 6) return false;
        $a = explode('.', $address); //address into array
        $oct = $a[sizeof($a) - 1] ?? '0'; //last byte or word
        $last = base_convert($oct, 10, 16);
        $zero = '/^0+$/';
        $ff = '/^[fF]{2,}$/';
        return preg_match($zero, $last)
            || preg_match($ff, $last);
    }

    private function type($addr): int
    { // used to validate and determine ip version
       if(filter_var($addr,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4))return 4;
       if(filter_var($addr,FILTER_VALIDATE_IP,FILTER_FLAG_IPV6))return 6;
       return 0 ;
    }

    private function ip2gmp($address)
    {
        return gmp_init(bin2hex(inet_pton($address)), 16);
    }

    private function gmp2ip($address)
    {
        $str = gmp_strval($address, 16);
        if (strlen($str) % 2) $str =
            str_pad('0', strlen($str) + 1, $str, STR_PAD_LEFT);
        return inet_ntop(hex2bin($str));
    }

    private function gmp_hosts($type,$len=null)
    {
        $sizes = [4 => 32,6=>128] ;
        $lens = [4=>28, 6=>54] ;
        $size = $sizes[$type];
        if(!$len) $len = $lens[$type];
        $base = 2;
        return gmp_pow($base, $size - $len);
    }

    private function gmp_range($prefix)
    {
        $split = explode('/', $prefix);
        $pref = $split[0] ?? null ;
        $len = $split[1] ?? null ;
        $type = $this->type($pref);
        $hosts = $this->gmp_hosts($type,$len);
        $addr = $this->ip2gmp($pref);
        $last = gmp_add($addr, $hosts);
        return ['start' => $addr, 'end' => $last];
    }

}