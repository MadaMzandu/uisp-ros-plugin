<?php
include_once 'lib/api_router.php';
$file = 'data/queue.json';
$global = null ;

function run_queue()
{
    global $queue ;
    $queue = read_queue();
    if(is_object($queue)){
        $ids = array_keys((array)$queue);
        foreach ($ids as $id){
            $status =  exec_item($queue->$id);
            if($status->error){
                $queue->$id->last = (new DateTime())->format('Y-m-d H:i:s');
                $queue->$id->status = $status ;
            }else{
                unset($queue->$id);
            }
        }
        echo 1 ; //save_queue();
    }
}

function exec_item($item): object
{
    $item->data->queued = true ;
    $api = new API_Router($item->data);
    $api->route();
    return $api->status();
}

function save_queue()
{
    global $file, $queue ;
    $json = json_encode($queue) ;
    return file_put_contents($file,$json);
}

function read_queue(): ?object
{
    global $file;
    if(file_exists($file)){
        $json = file_get_contents($file);
        return json_decode($json);
    }
    return null ;
}