<?php
include_once 'lib/api_router.php';
require_once 'vendor/autoload.php';

$data = [
    'changeType' => 'admin',
    'target' => 'config',
    'action' => 'edit',
    'data' => [
        'disable_contention' => false,
    ],

];

$t = new API_Router($data);
$t->route();
echo json_encode($t->status()) . "\n";