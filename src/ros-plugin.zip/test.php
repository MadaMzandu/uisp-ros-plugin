<?php
include_once 'lib/app_router.php';

$data = json_decode(file_get_contents('test.json'));
(new CS_SQLite())->delete(227);
$api = new CS_Router($data);
$api->route();
var_dump($api->http_response());