<?php
include_once "lib/api_router.php";
include_once "lib/timer.php";

$file  = file_get_contents('test.json');
function make_data($action,$index,$data,$type=1){
    $data->extraData->entityBeforeEdit = $data->extraData->entity ;
    if($action == 'insert') unset($data->extraData->entityBeforeEdit);
    $stat = ['delete' => 2,'suspend' => 3];
    $data->entityId = $index ;
    $data->changeType = $action ;
    $data->extraData->entity->id = $index ;
    $data->extraData->entity->status = $stat[$action] ?? 1;
    $data->extraData->entity->clientId = 2000+$index ;
    $mac = str_split(strtoupper(dechex(65534-$index)),2);
    $ip = '192.168.';
    $ip .= hexdec($mac[0]) . '.' . hexdec($mac[1]);
    if($type == 0){
        $data->extraData->entity->attributes[1]->key = "macAddress";
        $data->extraData->entity->attributes[1]->value = "54:AA:75:44:" . implode(":",$mac);
    }else{
        $data->extraData->entity->attributes[2]->value = 'user' . '-' . $index ;
        if($type == 2){
            $data->extraData->entity->attributes[1]->value = 1 ;
        }
    }
    $data->extraData->entity->attributes[4]->value = null ; // $ip ;
    return $data ;
}

$data = ['profile' => 'Internet 1Mbps'];
$count = 512 ;
while($count-- >= 502){
    $d = json_decode($file) ;
    $r = new API_Router(make_data('insert',$count+1,$d,1));
    $r->route();
    echo json_encode($r->status()) . "\n";
}

//$db = new API_SQLite();
//$db->deleteAll('services');
