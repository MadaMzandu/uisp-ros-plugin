<?php
include_once 'lib/api_sqlite.php';
include_once 'lib/api_logger.php';
include_once 'lib/api_router.php';
include_once 'lib/api_ip.php';
include_once 'lib/routeros_api.class.php';

$api = new RouterosAPI();
$api->connect('172.20.3.1','api',null);
$read = $api->write('/ip/dhcp-server/lease/print',false);
$api->write('?mac-address=64:C2:DE:50:92:A1');
$lease = $api->read()[0] ?? null;
$id = $lease['.id'] ?? null ;

$api->write('/ip/dhcp-server/lease/make-static',false);
$api->write('=.id='.$id);
$out = $api->read();

echo 1;


