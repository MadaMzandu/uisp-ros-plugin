<?php
include_once "lib/api_router.php";
include_once "lib/timer.php";

$data = json_decode(file_get_contents('test.json'));


$api = new API_Router($data);
$api->route();
echo $api->http_response() . "\n";
