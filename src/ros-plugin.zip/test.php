<?php
include_once 'lib/api_router.php';
require_once 'vendor/autoload.php';
include_once 'test_class.php';
$data = json_decode(file_get_contents('test.json'));
$r= new API_Router($data);
$r->route();
echo json_encode($r->status()). "\n";