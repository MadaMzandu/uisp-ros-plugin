<?php
include_once 'lib/api_router.php';
include_once 'lib/api_sqlite.php';
require_once 'vendor/autoload.php';

$data = [
    'changeType' => 'admin',
    'target' => 'system',
    'action' => 'rebuild',
    'data' => [
        'disable_contention' => false,
    ],

];

$t = new API_Router($data);
$t->route();
echo json_encode($t->status()) . "\n";
