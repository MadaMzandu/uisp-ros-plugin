<?php
include_once 'lib/api_router.php';
require_once 'vendor/autoload.php';
include_once 'test_class.php';
$data = json_decode(file_get_contents('test.json'));
$s = new Service($data);
$s->plan->contention = 1;
$p = new MT_Profile($s);
$p->set_profile();

//echo json_encode($r,128) ."\n";