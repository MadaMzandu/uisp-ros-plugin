<?php
include_once 'lib/api_router.php';
include_once 'lib/api_sqlite.php';
require_once 'vendor/autoload.php';

$data = json_decode(file_get_contents('test.json'));



$t = new API_Router($data);
$t->route();
echo $t->http_response() . "\n";

