<?php
include_once 'lib/api_router.php';
//include_once 'lib/api_sqlite.php';
require_once 'vendor/autoload.php';
include_once 'test_class.php';
/*$data = json_decode(file_get_contents('test.json'));
$a = new API_Router($data);
$a->route();
var_dump($a->status());*/

$d = new API_SQLite();
$a = $d->selectAllFromTable('services');
var_dump($a);