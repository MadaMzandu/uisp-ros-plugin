<?php
include "lib/api_sqlite.php";
include "lib/api_ip.php" ;

$data = [];
$device = (object)['pool' => '10.0.0.0/8','pool6' => 'fdeb:760a:829d::/48'];
$count = 20000 ;
$ip = new API_IP();
while($count-- == 20000){
	[$ip,$ip6] = $ip->assign($device);
	$row = [$count,1,$ip,$ip6,$count+10000,4,1];
$data[] = "(" . implode(",",$row) . ")";
}
$sql = "insert into services (id,device,address,prefix6,clientId,planId,status) values " . implode(",",$data);
var_dump($data);


