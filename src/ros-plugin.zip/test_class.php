<?php
include_once 'lib/api_jobs.php';
include_once 'lib/api_router.php';

class API_Test
{
    private $json;
    private $data;
    private $devices = ['Home', 'Mtl'];
    private $dst = 1;
    private $src = 0;


    public function __construct()
    {
        $this->json = file_get_contents('test.json');
    }

    public function values(): void
    {
        $data = json_decode($this->json);
        $serv = new Service($data);
        echo "Service\n";
        $s_keys = "id,ip,mac,username,password,exists,status";
        foreach (explode(',', $s_keys) as $key) {
            echo json_encode([$key => $serv->$key()]) . "\n";
        }
        echo json_encode(['device' => $serv->device()]) . "\n";
        $o_keys = "ready,mode,pppoe";
        foreach (explode(',', $o_keys) as $key) {
            echo json_encode([$key => $serv->$key]) . "\n";
        }
        echo "Plan\n";
        $p_keys = "name,children,id,rate,total";
        foreach (explode(',', $p_keys) as $key) {
            echo json_encode([$key => $serv->plan->$key()]) . "\n";
        }
        echo json_encode(['contention' => $serv->plan->contention]) . "\n";
        echo "Client\n";
        $c_keys = "id,name";
        foreach (explode(',', $c_keys) as $key) {
            echo json_encode([$key => $serv->client->$key()]) . "\n";
        }
    }

    public function run_tests($mode=0)
    {
        global $tests ;
        $data = json_decode($tests);
        $actions = ['insert','edit','suspend','unsuspend','end'];
        foreach ($data as $test){
            foreach($actions as $action){
                $this->data = $this->data();
                $this->setAttr($test->attribute,$test->value,$mode);
                echo $test->name . ": ". $action. " \n";
                $this->exec();
            }
        }
    }

    public function validate()
    {
        $key_string = "pppoeUsername,dhcpMacAddress,deviceName";
        foreach (explode(',', $key_string) as $key) {
            $index = $this->find($key);
            if (is_int($index)) {
                echo $key . "\n";
                $this->data = json_decode($this->json);
                unset($this->data->extraData->entity->attributes[$index]);
                $s = new Service($this->data);
                echo json_encode($s->status()) . "\n";
            }
        }
    }

    private function find($key): ?int
    {
        $data = json_decode($this->json, true);
        $array = $data['extraData']['entity']['attributes'];
        $index = null;
        $count = 0;
        foreach ($array as $item) {
            if ($item['key'] == $key) {
                $index = $count;
            }
            $count++;
        }
        return $index;
    }

    public function name_change()
    {
        $this->insert();
        $this->data = $this->data();
        $this->setAttr('pppoeUsername', 'bonobo');
        $this->data->changeType = 'edit';
        $this->exec();
        $this->data->changeType = 'end';
        $this->setAttr('pppoeUsername', 'bonobo',1);
        $this->exec();
    }

    public function rebuild()
    {
        $this->data = (object)[
            'changeType' => 'admin',
            'target' => 'system',
            'action' => 'rebuild',
            'data' => []
        ];
        $this->exec();
    }

    public function contend($reps=5)
    {
        $this->bulk_insert($reps);
        $this->bulk_insert($reps,true);
    }

    public function job_run()
    {
        $data= [];
        $q = new Api_Queue($data);
        $q->run();
    }

    public function job_queue($reps=3,$delete=false)
    {
        $file = 'data/queue.json';
        if(file_exists($file)){
            file_put_contents($file,"{}");
        }
        $db = $this->db() ;
        $devs = $db->selectAllFromTable('devices');
        $db->exec("update devices set password='bogus'"); // set bogus pass to fail connection
        $this->bulk_insert($reps,$delete);
        foreach ($devs as $dev){ // restore passwords
            $db->edit($dev,'devices');
        }
    }

    private function db()
    {
       return new API_SQLite() ;
    }

    private function bulk_insert($reps=2,$delete = false)
    {
        $count = 0 ;
        while($count < $reps){
            $this->data = $this->data();
            $ext = strlen((string)$count) < 2
                ? '0' . dechex($count) : dechex($count);
            if ($this->is_pppoe()) {
                $this->setAttr('pppoeUsername',
                    'pppuser' . $ext);
            } else {
                $this->setAttr('dhcpMacAddress',
                    '64:D1:54:4B:B6:' . $ext);
            }
            $this->data->changeType = $delete ? 'end' : 'insert';
            $id = 300 + $count ;
            $this->data->entityId = $id;
            $this->data->extraData->entity->id = $id;
            unset($this->data->extraData->entityBeforeEdit);
            $this->exec();
            $count++;
        }
    }

    private function is_pppoe()
    {
        foreach ($this->data->extraData->entity->attributes as $item) {
            if ($item->key == 'dhcpMacAddress' && isset($item->value)) {
                return false;
            }
            if ($item->key == 'pppoeUsername' && isset($item->value)) {
                return true;
            }
        }
    }

    private function data()
    {
        return json_decode($this->json);
    }

    public function insert()
    {
        $this->data = $this->data();
        $this->data->changeType = 'insert';
        unset($this->data->extraData->entityBeforeEdit);
        $this->exec();
    }

    public function deleteAll()
    {
        foreach ($this->devices as $device) {
            $this->data = $this->data();
            $this->data->changeType = 'end';
            $this->setAttr('deviceName', $device);
            $this->exec();
        }
    }

    private function exec()
    {
        $r = new API_Router($this->data);
        $r->route();
        echo json_encode($r->status()) . "\n";
    }

    public function delete()
    {
        $this->data = $this->data();
        $this->data->changeType = 'end';
        $this->exec();
    }

    public function edit()
    {
        $this->data = $this->data();
        $this->data->changeType = 'edit';
        $this->setAttr('pppoeUsername','bonobo');
        $this->exec();
    }

    public function suspend()
    {
        $this->insert();
        $this->change_status(3);
        $this->exec();
        $this->change_status(1);
        $this->exec();
        $this->delete();
    }

    private function change_status($status)
    {
        $this->data = $this->data();
        $unsuspend = $status == 1 ;
        $this->data->changeType = $unsuspend ? 'unsuspend' : 'suspend';
        $this->data->extraData->entity->status = $unsuspend ? 1 : 3;
        $this->data->extraData->entityBeforeEdit->status = $unsuspend ? 3 : 1;
    }

    public function move($reps=2)
    {
        $this->insert();
        $count=0;
        while($count < $reps)
        {
            $this->change_device();
            $this->exec();
            $count++;
        }
        $this->delete();
    }

    private function change_device()
    {
        $this->data = $this->data();
        $this->data->changeType = 'edit';
        $dst = $this->devices[$this->dst];
        $src = $this->devices[$this->src];
        $this->setAttr('deviceName', $dst);
        $this->setAttr('deviceName', $src,1);
        $this->dst = $this->dst == 0 ? 1 : 0;
        $this->src = $this->src == 0 ? 1 : 0;
    }

    private function setAttr($key,$value,$entity=0)
    {
        $modes = ['entity','entityBeforeEdit'];
        if(isset($this->data->extraData->{$modes[$entity]})) {
            foreach ($this->data->extraData->{$modes[$entity]}->attributes as $item) {
                if ($item->key == $key) {
                    $item->value = $value;
                }
            }
        }
    }
}

$tests = '[{"name":"Missing device","attribute":"deviceName","value":""},{"name":"Dead device","attribute":"deviceName","value":"NoDevice"},{"name":"Missing username","attribute":"pppoeUsername","value":""},{"name":"Has caller identity","attribute":"callerId","value":"64:D1:54:F5:E1:31"},{"name":"Missing caller identity","attribute":"callerId","value":""}]';