<?php

class API_Test
{
    private $json;
    private $data;
    private $devices = ['Test', 'Test2'];
    private $dst = 1;
    private $src = 0;

    public function __construct()
    {
        $this->json = file_get_contents('test.json');
    }

    public function values(): void
    {
        $data = json_decode($this->json);
        $serv = new Service($data);
        echo "Service\n";
        $s_keys = "id,ip,mac,username,password,exists,status";
        foreach (explode(',', $s_keys) as $key) {
            echo json_encode([$key => $serv->$key()]) . "\n";
        }
        echo json_encode(['device' => $serv->device()]) . "\n";
        $o_keys = "ready,move,pppoe";
        foreach (explode(',', $o_keys) as $key) {
            echo json_encode([$key => $serv->$key]) . "\n";
        }
        echo "Plan\n";
        $p_keys = "name,children,id,rate,total";
        foreach (explode(',', $p_keys) as $key) {
            echo json_encode([$key => $serv->plan->$key()]) . "\n";
        }
        echo json_encode(['contention' => $serv->plan->contention]) . "\n";
        echo "Client\n";
        $c_keys = "id,name";
        foreach (explode(',', $c_keys) as $key) {
            echo json_encode([$key => $serv->client->$key()]) . "\n";
        }
    }

    public function validate()
    {
        $key_string = "pppoeUsername,dhcpMacAddress,deviceName";
        foreach (explode(',', $key_string) as $key) {
            $index = $this->find($key);
            if (is_int($index)) {
                echo $key . "\n";
                $this->data = json_decode($this->json);
                unset($this->data->extraData->entity->attributes[$index]);
                $s = new Service($this->data);
                echo json_encode($s->status()) . "\n";
            }
        }
    }

    private function find($key): ?int
    {
        $data = json_decode($this->json, true);
        $array = $data['extraData']['entity']['attributes'];
        $index = null;
        $count = 0;
        foreach ($array as $item) {
            if ($item['key'] == $key) {
                $index = $count;
            }
            $count++;
        }
        return $index;
    }

    public function name_change()
    {
        $this->insert();
        $this->data = $this->data();
        $this->setAttrib('entity', 'pppoeUsername', 'bonobob');
        $this->data->changeType = 'edit';
        $this->exec();
        $this->data->changeType = 'end';
        $this->exec();
    }

    public function rebuild()
    {
        $this->data = (object)[
            'changeType' => 'admin',
            'target' => 'system',
            'action' => 'test',
            'data' => []
        ];
        $this->exec();
    }

    public function contend($index, $reverse = false)
    {
        $this->data = $this->data();
        $ext = strlen((string)$index) < 2
            ? '0' . dechex($index) : dechex($index);
        if ($this->is_pppoe()) {
            $this->setAttrib('entity', 'pppoeUsername',
                'pppuser' . $ext);
        } else {
            $this->setAttrib('entity', 'dhcpMacAddress',
                '64:D1:54:4B:B6:' . $ext);
        }


        $this->data->changeType = $reverse ? 'end' : 'insert';
        $this->data->extraData->entity->id = 300 + $index;
        unset($this->data->extraData->entityBeforeEdit);
        $this->exec();
    }

    private function is_pppoe()
    {
        foreach ($this->data->extraData->entity->attributes as $item) {
            if ($item->key == 'dhcpMacAddress' && isset($item->value)) {
                return false;
            }
            if ($item->key == 'pppoeUsername' && isset($item->value)) {
                return true;
            }
        }
    }

    private function data()
    {
        return json_decode($this->json);
    }

    public function insert()
    {
        $this->data = $this->data();
        $this->data->changeType = 'insert';
        unset($this->data->extraData->entityBeforeEdit);
        $this->exec();
    }

    public function deleteAll()
    {
        foreach ($this->devices as $device) {
            $this->data = $this->data();
            $this->data->changeType = 'end';
            $this->setAttrib('entity', 'deviceName', $device);
            $this->exec();
        }
    }

    private function exec()
    {
        $r = new API_Router($this->data);
        $r->route();
        echo json_encode($r->status()) . "\n";
    }

    public function delete()
    {
        $this->data = $this->data();
        $this->data->changeType = 'end';
        $this->exec();
    }

    public function edit()
    {
        $this->data = $this->data();
        $this->data->changeType = 'edit';
        $this->exec();
    }

    public function suspend($unsuspend = false)
    {
        $this->data = $this->data();
        $this->data->changeType = $unsuspend ? 'unsuspend' : 'suspend';
        $this->data->extraData->entity->status = $unsuspend ? 1 : 3;
        $this->data->extraData->entityBeforeEdit->status = $unsuspend ? 3 : 1;
        $this->exec();
    }

    public function move()
    {
        $this->data = $this->data();
        $this->data->changeType = 'edit';
        $dst = $this->devices[$this->dst];
        $src = $this->devices[$this->src];
        $this->setAttrib('entity', 'deviceName', $dst);
        $this->setAttrib('entityBeforeEdit', 'deviceName', $src);
        $this->dst = $this->dst == 0 ? 1 : 0;
        $this->src = $this->src == 0 ? 1 : 0;
        $this->exec();
    }

    private function setAttrib($entity, $key, $value)
    {
        foreach ($this->data->extraData->$entity->attributes as $item) {
            if ($item->key != $key) continue;
            $item->value = $value;
            return;
        }
    }

}