
This directory contains the language files for the plugin. There two files for each language fields_xx.json and messages_xx.json where xx is the code for the language.

Both files are in the json format of "key" : "value". In order to translate the language the values need to be edited and the keys need to remain unedited. The fields file has a tree of keys "key" : { "key" : "value, "key" : "value ..etc. again only the values need to be edited.

Example to translate from English:

1. Copy fields_en.json and messages_en.json and replace 'en' with your language code.
2. Edit the values accordingly.
3. Either create a pull request or just attach as email and send them to me and I will merge them into the code for next version release.

You time and contibutions are massively appreciated.
